Bloque 3 – Personalidad de marca y moodboard (15 minutos)
Antes de elegir colores y tipografías, necesitas saber qué quieres comunicar. Si no, terminas eligiendo lo que te gusta visualmente, sin justificación profesional.

Paso 6. Definir los atributos de marca
Crea el archivo BRAND.md y completa esta plantilla:

# Identidad de marca — [AGENTE X]

## Audiencia objetivo
Gestores, administradores o perfiles técnicos (25-50 años) que necesitan control e interpretación de sus sistemas en tiempo real desde su móvil. Tienen poco tiempo, desprecian la fricción, y exigen respuestas precisas e inmediatas a través de plataformas accesibles.

## Promesa de valor
Podras acceder a los datos importantes de tu empresa en tiempo real de forma resumida, procesada por una inteligencia artificial. 
Ahorrandote tiempo crucial. 

## 5 atributos de marca (elige 5 — no más, no menos)
1. Eficiente: Hace el trabajo rápido, sin pasos extra ni adornos.
2. Preciso: La información que entrega es rigurosa, exacta y accionable.
3. Minimalista: Cero ruido visual o textual; directo al grano.
4. Tecnológico: Se percibe como un sistema automatizado avanzado y moderno.
5. Accesible: Interacción natural y sin barreras de entrada para el usuario.

## Lo que NO somos (3 ejemplos)
1. No somos lúdicos ni chistosos: El usuario confía datos críticos en nosotros; no quiere memes ni emojis innecesarios, quiere resultados.
2. No somos invasivos: No saturamos con notificaciones de estado inútiles. 
3. No somos un panel de control saturado, Huimos de la sobrecarga cognitiva, ya que es el principal dolor de mi publico objetivo. 

## Tono de voz (un ejemplo)
- Cómo escribimos un mensaje de error:"Error de conexión con la base de datos principal. Sistema reintentando la extracción en 5 segundos. Ninguna acción requerida por ahora."
- Cómo escribimos un mensaje de éxito: "Extracción completada con éxito, Agente preparando respuesta..."  



Rol,Token,HEX,Uso
Primario,--color-primary,#2563EB,"Botones primarios, links, llamadas a la acción vitales"
Primario hover,--color-primary-hover,#1D4ED8,Estado hover de botones primarios
Secundario,--color-accent,#38BDF8,"Elementos destacados pequeños, badges técnicos"
Texto principal,--color-text,#F8FAFC,Cuerpo de texto principal (casi blanco)
Texto secundario,--color-text-muted,#94A3B8,"Descripciones, timestamps, metadatos"
Fondo,--color-bg,#020617,Fondo general de la aplicación (slate ultra oscuro)
Fondo alternativo,--color-bg-alt,#0F172A,"Tarjetas, modales, hover de filas"
Borde,--color-border,#1E293B,Separadores finos para dividir información
Éxito,--color-success,#10B981,"Confirmaciones, sistema ""OK"""
Error,--color-danger,#EF4444,"Alertas críticas, caídas del sistema, eliminar"
Advertencia,--color-warning,#F59E0B,"Avisos de uso de memoria, reintentos"
Info,--color-info,#3B82F6,"Información neutra, actualizaciones de estado"


Brief del logo — Agente X
Nombre: Agente X

Categoría: B2B Tech / Automated Data Extraction Agent

Atributos: Eficiente, Preciso, Minimalista, Tecnológico, Accesible.

Estilo deseado: Minimalista, geométrico, flat design, icon-based.

Símbolo opcional: Fusión de un 'X' y un elemento de observación (ojo sensor, flujo de datos).

Colores base: Primario #2563EB y Accent #38BDF8.

NO quiero: 3D, detalles complejos, degradados orgánicos, tipografía lúdica.



Atribución y licencias
Logo y Elementos Gráficos: Generados con asistencia de IA (Imagen_Gen) el [FECHA ACTUAL], refinados manualmente. Términos de uso revisados: [Link de licencia comercial de la herramienta].

Tipografías: Inter y JetBrains Mono desde Google Fonts (Open Font License).

Paleta de colores: Original, generada y documentada en Bloque 4.    