1. ¿Cuáles fueron los 3 hallazgos más graves de tu evaluación heurística y qué heurística violaba cada uno?
(Nota para Mauricio: Ajusta esto a tu pantalla real, aquí tienes el estándar de un agente de datos)

Falta de visibilidad del estado del sistema: El usuario lanzaba una extracción de datos y la interfaz no mostraba si el bot estaba trabajando, en pausa o caído.

Prevención de errores deficiente: Los inputs para configurar los parámetros del agente no tenían validación en tiempo real, permitiendo enviar solicitudes que la base de datos iba a rechazar.

Flexibilidad y eficiencia de uso: Faltaban atajos o flujos rápidos para reiniciar una tarea fallida; obligaba al usuario a repetir configuraciones desde cero.

2. ¿Por qué un diseño accesible (WCAG AA) mejora la experiencia incluso de usuarios sin discapacidad? Da dos ejemplos concretos.
Porque la accesibilidad reduce la fricción cognitiva en entornos no ideales.

Ejemplo 1: Un administrador revisando el estado del agente desde su móvil en la calle bajo la luz del sol necesita un contraste alto (18:1 como el que configuramos) para poder leer los datos sin forzar la vista.

Ejemplo 2: Un desarrollador que lleva 10 horas programando frente a la pantalla sufre fatiga visual; un modo oscuro bien balanceado con jerarquía clara le permite escanear logs sin esfuerzo.

3. ¿Por qué decidiste estos 5 atributos de marca y no otros? ¿Qué decisiones de color/tipografía se desprenden directamente de ellos?
Elegí Eficiente, Preciso, Minimalista, Tecnológico y Accesible porque el sistema es una herramienta de extracción y automatización en segundo plano, no una red social. De la precisión se desprende el uso de JetBrains Mono para los datos (evita confundir un '0' con una 'O'). Del minimalismo y tecnología se desprende el fondo oscuro profundo (#020617) con un único acento azul eléctrico, eliminando cualquier ruido visual que no aporte datos útiles.

4. Tu paleta tiene un color primario y un acento. ¿Por qué no más? ¿Qué problema causa una paleta con 8 colores primarios?
Porque el color en una interfaz técnica es información, no decoración. Si uso 8 colores, el usuario pierde de inmediato la capacidad de distinguir qué es importante. Un único color primario entrena al ojo del usuario a saber exactamente dónde hacer clic para avanzar. Múltiples colores generan sobrecarga cognitiva y parálisis de decisión.

5. La regla 60-30-10 te obliga a no saturar la pantalla. Identifica una zona de tu UI actual donde esta regla se rompe. ¿Cómo la corregirías?
(Nota para Mauricio: Revisa tu UI. Lo típico es esto): Tenía paneles enteros o múltiples botones compitiendo por atención usando el color primario de fondo. Lo corrijo pasando el 60% al fondo oscuro estricto, el 30% a tarjetas en un tono ligeramente más claro (--color-bg-alt) y reservando el 10% (el color primario) estrictamente para el botón de "Ejecutar Extracción".

6. Hoy generaste un logo con IA. Enumera dos riesgos de hacerlo así y cómo los mitigaste.

Riesgo de artefactos y no escalabilidad (Raster vs Vector): La IA genera píxeles que se deforman. Lo mitigé extrayendo el concepto y trazándolo en SVG para tener vectores matemáticamente perfectos.

Riesgo de falta de identidad / genérico: La IA tiende a hacer logos genéricos si el prompt es débil. Lo mitigé imponiendo restricciones geométricas estrictas, bloqueando estilos 3D o degradados, y forzando el uso exclusivo de los colores HEX de mi paleta técnica.

7. ¿Qué relación ves entre tener un design system y escribir código mantenible? Explica con un ejemplo de tu propio repositorio.
Es exactamente el mismo principio de no repetirse (DRY - Don't Repeat Yourself). Tener un Design System (usar var(--color-danger)) es idéntico a tener una función centralizada en Python para manejar las excepciones de Selenium. Si mañana cambia el color de alerta o la lógica de error, lo actualizo en el archivo de variables o en la función central, y el cambio impacta en todo el sistema. Escribir códigos HEX a mano en cada componente es el equivalente visual a hacer hardcode de consultas SQL en cada vista.

8. Si tuvieras que defender ante un cliente por qué eligieron Inter en vez de Comic Sans, ¿cuál sería tu argumento técnico?
No hablaría de estética. Argumentaría que Inter fue diseñada específicamente para pantallas de computadora y legibilidad a tamaños pequeños. Tiene una altura de la 'x' grande, proporciones geométricas que facilitan el escaneo rápido de tablas de datos, y pesos tipográficos optimizados para renderizarse con nitidez en monitores de alta y baja resolución. Comic Sans tiene trazos irregulares que destruyen el ritmo de lectura de datos tabulares y reducen drásticamente la velocidad de procesamiento de información del administrador.

¿Qué decisión visual de tu proyecto tendrías que cambiar mañana después de este laboratorio?
Eliminar cualquier estilo "en línea" (inline styles) y cualquier valor hardcodeado en la interfaz para migrar todo al 100% al uso del archivo tokens.css. Si no está en el token, no existe en el proyecto.

¿Qué cosa hacías "porque sí" antes y ahora puedes justificar técnicamente?
Elegir tipografías y colores. Antes los elegía por "gusto personal". Ahora entiendo que elegir una fuente monoespaciada para los logs o un esquema de color de alto contraste es una decisión de usabilidad y rendimiento cognitivo, tan crítica como optimizar un script de automatización.