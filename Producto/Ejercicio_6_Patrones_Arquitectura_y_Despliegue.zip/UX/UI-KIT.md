Regla,Acción,Estado
Fondo,Usar logo a color completo sobre #020617 o #0F172A.,✅
Monocromo,Usar versión blanca sobre fondos oscuros no oficiales.,✅
Isotipo,Usar solo el símbolo 'X' para avatares y favicons (≤32px).,✅
Proporción,No estirar ni comprimir el logo.,❌
Efectos,"No aplicar sombras, biseles ni efectos 3D.",❌
Colores,"No usar colores fuera de la paleta oficial (#2563EB, #38BDF8).",❌



## Componentes Base

### Botones
- **Primario:** Fondo `--color-primary`, texto blanco, padding 8px 16px, radio `--radius-sm`, fuente `--font-mono` (técnico).
- **Secundario:** Fondo transparente, borde 1px `--color-border`, texto `--color-text`. (Para acciones de bajo impacto).
- **Destructivo:** Fondo `--color-danger` al 20%, borde 1px `--color-danger`, texto rojo puro. (Para borrar bases de datos o detener agentes).
- **Estados:** Hover (cambio a `--color-primary-hover`), Disabled (opacidad 50%, cursor `not-allowed`).

### Inputs (Terminal / Log Search)
- Fondo `--color-bg-alt`, borde 1px `--color-border`, texto `--color-text`, fuente `--font-mono`.
- Focus: Borde `--color-primary` (sin anillos brillantes exagerados).

### Tarjetas (Cards de Datos)
- Fondo `--color-bg-alt`, borde 1px `--color-border`, radio `--radius-md`, padding `--space-4`. 
- Sombra: `--shadow-sm` (casi imperceptible en modo oscuro, solo para separar profundidad).

### Mensajes (Alertas del Sistema)
- Layout tipo "Toast" en esquina superior derecha. 
- Borde izquierdo grueso (4px) del color semántico correspondiente (Éxito, Error, Advertencia), fondo `--color-bg-alt`.